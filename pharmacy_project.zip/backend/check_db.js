const db = require('./config/db');

async function run() {
  try {
    const [tables] = await db.query("SHOW TABLES;");
    console.log("Tables:", JSON.stringify(tables, null, 2));

    for (const tableRow of tables) {
      const tableName = Object.values(tableRow)[0];
      const [schema] = await db.query(`SHOW CREATE TABLE ${tableName};`);
      console.log(`\n--- Schema for ${tableName} ---`);
      console.log(schema[0]['Create Table']);
    }

    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
