// Main Server File
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// ==================== MIDDLEWARE ====================
app.use(cors());             // Allow frontend to connect
app.use(express.json());     // Parse JSON request bodies

// ==================== ROUTES ====================
app.use('/api/auth', require('./routes/auth'));
app.use('/api/medicines', require('./routes/medicines'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/reports', require('./routes/reports'));

// ==================== TEST ROUTE ====================
app.get('/', (req, res) => {
  res.json({ message: 'Pharmacy Management System API is running' });
});

// ==================== START SERVER ====================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
