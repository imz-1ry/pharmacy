const db = require('./config/db');

async function run() {
  try {
    console.log("Fixing foreign key constraints for sale_details...");
    await db.query("ALTER TABLE sale_details DROP FOREIGN KEY sale_details_ibfk_1;");
    await db.query("ALTER TABLE sale_details ADD CONSTRAINT sale_details_ibfk_1 FOREIGN KEY (sale_id) REFERENCES sales (sale_id) ON DELETE CASCADE;");
    
    await db.query("ALTER TABLE sale_details DROP FOREIGN KEY sale_details_ibfk_2;");
    await db.query("ALTER TABLE sale_details ADD CONSTRAINT sale_details_ibfk_2 FOREIGN KEY (med_id) REFERENCES medicines (med_id) ON DELETE CASCADE;");

    console.log("Fixing foreign key constraints for sales...");
    await db.query("ALTER TABLE sales DROP FOREIGN KEY sales_ibfk_1;");
    await db.query("ALTER TABLE sales ADD CONSTRAINT sales_ibfk_1 FOREIGN KEY (cust_id) REFERENCES customers (cust_id) ON DELETE CASCADE;");

    console.log("Deleting 'Amoxicillin'...");
    await db.query("DELETE FROM medicines WHERE med_name LIKE '%amoxicil%';");

    console.log("Deleting user 'makoma'...");
    await db.query("DELETE FROM users WHERE username = 'makoma';");

    console.log("Success! Database fixed and requested records removed.");
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
