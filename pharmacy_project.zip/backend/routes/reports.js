// Reports Routes (Daily Sales Report)
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// ==================== DAILY SALES REPORT ====================
// GET /api/reports/daily?date=2024-01-15
router.get('/daily', auth, async (req, res) => {
  try {
    const { date } = req.query;

    // Get all sales for the given date with details
    const [report] = await db.query(
      `SELECT s.sale_id, s.date, c.name AS customer_name,
              m.med_name, sd.quantity, m.price,
              (sd.quantity * m.price) AS item_total
       FROM sales s
       LEFT JOIN customers c ON s.cust_id = c.cust_id
       JOIN sale_details sd ON s.sale_id = sd.sale_id
       JOIN medicines m ON sd.med_id = m.med_id
       WHERE s.date = ?
       ORDER BY s.sale_id`,
      [date]
    );

    // Calculate total revenue for the day
    const totalRevenue = report.reduce((sum, row) => sum + parseFloat(row.item_total), 0);

    res.json({ date, report, totalRevenue });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
