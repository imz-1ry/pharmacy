// Medicine Routes (CRUD + Expiry Alerts)
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// ==================== GET ALL MEDICINES ====================
// GET /api/medicines
router.get('/', auth, async (req, res) => {
  try {
    const [medicines] = await db.query('SELECT * FROM medicines ORDER BY med_name');
    res.json(medicines);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== EXPIRY ALERTS ====================
// GET /api/medicines/alerts/expiring  <-- MUST be before /:id to avoid route conflict
router.get('/alerts/expiring', auth, async (req, res) => {
  try {
    const [medicines] = await db.query(
      `SELECT * FROM medicines 
       WHERE expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
       AND expiry_date >= CURDATE()
       ORDER BY expiry_date ASC`
    );
    res.json(medicines);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== GET ONE MEDICINE ====================
// GET /api/medicines/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const [medicine] = await db.query('SELECT * FROM medicines WHERE med_id = ?', [req.params.id]);
    if (medicine.length === 0) {
      return res.status(404).json({ message: 'Medicine not found' });
    }
    res.json(medicine[0]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== ADD MEDICINE ====================
// POST /api/medicines
router.post('/', auth, async (req, res) => {
  try {
    const { med_name, quantity, price, expiry_date } = req.body;
    const [result] = await db.query(
      'INSERT INTO medicines (med_name, quantity, price, expiry_date) VALUES (?, ?, ?, ?)',
      [med_name, quantity, price, expiry_date]
    );
    res.status(201).json({ message: 'Medicine added', med_id: result.insertId });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== UPDATE MEDICINE ====================
// PUT /api/medicines/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const { med_name, quantity, price, expiry_date } = req.body;
    const [result] = await db.query(
      'UPDATE medicines SET med_name = ?, quantity = ?, price = ?, expiry_date = ? WHERE med_id = ?',
      [med_name, quantity, price, expiry_date, req.params.id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Medicine not found' });
    }
    res.json({ message: 'Medicine updated' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== DELETE MEDICINE ====================
// DELETE /api/medicines/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM medicines WHERE med_id = ?', [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Medicine not found' });
    }
    res.json({ message: 'Medicine deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
