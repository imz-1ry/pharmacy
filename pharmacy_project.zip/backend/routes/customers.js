// Customer Routes (CRUD)
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// ==================== GET ALL CUSTOMERS ====================
// GET /api/customers
router.get('/', auth, async (req, res) => {
  try {
    const [customers] = await db.query('SELECT * FROM customers ORDER BY name');
    res.json(customers);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== GET ONE CUSTOMER ====================
// GET /api/customers/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const [customer] = await db.query('SELECT * FROM customers WHERE cust_id = ?', [req.params.id]);
    if (customer.length === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    res.json(customer[0]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== ADD CUSTOMER ====================
// POST /api/customers
router.post('/', auth, async (req, res) => {
  try {
    const { name, phone } = req.body;
    const [result] = await db.query(
      'INSERT INTO customers (name, phone) VALUES (?, ?)',
      [name, phone]
    );
    res.status(201).json({ message: 'Customer added', cust_id: result.insertId });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== UPDATE CUSTOMER ====================
// PUT /api/customers/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const { name, phone } = req.body;
    const [result] = await db.query(
      'UPDATE customers SET name = ?, phone = ? WHERE cust_id = ?',
      [name, phone, req.params.id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    res.json({ message: 'Customer updated' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== DELETE CUSTOMER ====================
// DELETE /api/customers/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    const [result] = await db.query('DELETE FROM customers WHERE cust_id = ?', [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    res.json({ message: 'Customer deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
