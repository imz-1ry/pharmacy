// Sales Routes (Create Sale with Details, Get All Sales)
const express = require('express');
const router = express.Router();
const db = require('../config/db');
const auth = require('../middleware/auth');

// ==================== GET ALL SALES ====================
// GET /api/sales
router.get('/', auth, async (req, res) => {
  try {
    // Join sales with customer names
    const [sales] = await db.query(
      `SELECT s.sale_id, s.date, c.name AS customer_name, c.cust_id
       FROM sales s
       LEFT JOIN customers c ON s.cust_id = c.cust_id
       ORDER BY s.date DESC`
    );
    res.json(sales);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== GET SALE DETAILS ====================
// GET /api/sales/:id/details
router.get('/:id/details', auth, async (req, res) => {
  try {
    // Get sale details with medicine names and prices
    const [details] = await db.query(
      `SELECT sd.id, sd.quantity, m.med_name, m.price,
              (sd.quantity * m.price) AS total
       FROM sale_details sd
       JOIN medicines m ON sd.med_id = m.med_id
       WHERE sd.sale_id = ?`,
      [req.params.id]
    );
    res.json(details);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== CREATE NEW SALE ====================
// POST /api/sales
// Body: { cust_id, date, items: [{ med_id, quantity }] }
router.post('/', auth, async (req, res) => {
  try {
    const { cust_id, date, items } = req.body;

    // Step 1: Create the sale record
    const [saleResult] = await db.query(
      'INSERT INTO sales (cust_id, date) VALUES (?, ?)',
      [cust_id, date]
    );
    const sale_id = saleResult.insertId;

    // Step 2: Add each item to sale_details and update stock
    for (const item of items) {
      // Insert sale detail
      await db.query(
        'INSERT INTO sale_details (sale_id, med_id, quantity) VALUES (?, ?, ?)',
        [sale_id, item.med_id, item.quantity]
      );

      // Reduce medicine stock
      await db.query(
        'UPDATE medicines SET quantity = quantity - ? WHERE med_id = ?',
        [item.quantity, item.med_id]
      );
    }

    res.status(201).json({ message: 'Sale recorded', sale_id });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ==================== DELETE SALE ====================
// DELETE /api/sales/:id
router.delete('/:id', auth, async (req, res) => {
  try {
    // Sale_details are deleted automatically (CASCADE)
    const [result] = await db.query('DELETE FROM sales WHERE sale_id = ?', [req.params.id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Sale not found' });
    }
    res.json({ message: 'Sale deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;
