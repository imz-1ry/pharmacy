// JWT Authentication Middleware
const jwt = require('jsonwebtoken');
require('dotenv').config();

// This middleware checks if the user has a valid token
const auth = (req, res, next) => {
  // Get token from the request header
  const token = req.header('Authorization')?.replace('Bearer ', '');

  // If no token, deny access
  if (!token) {
    return res.status(401).json({ message: 'No token, access denied' });
  }

  try {
    // Verify the token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach user info to request
    next(); // Continue to the next function
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

module.exports = auth;
