import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { FileText, Calendar, TrendingUp, BarChart3, Receipt } from 'lucide-react';

function Reports() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [report, setReport] = useState([]);
  const [totalRevenue, setTotalRevenue] = useState(0);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  const fetchReport = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`http://localhost:5000/api/reports/daily?date=${date}`, { headers });
      setReport(res.data.report);
      setTotalRevenue(res.data.totalRevenue);
      setSearched(true);
      if (res.data.report.length === 0) {
        toast.info(`No sales found for ${new Date(date).toLocaleDateString()}.`);
      } else {
        toast.success(`Report loaded — ${res.data.report.length} transaction(s) found.`);
      }
    } catch {
      toast.error('Failed to generate report.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
            Analytics & Reports
          </h1>
          <p className="text-slate-400 mt-1">Generate and view daily revenue summaries</p>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-dark-800/60 border border-pharmacy-500/20 p-6 rounded-2xl mb-8 flex flex-col sm:flex-row items-end gap-4 shadow-lg">
        <div className="w-full sm:w-auto flex-1 max-w-xs">
          <label className="form-label flex items-center gap-2">
            <Calendar className="w-3.5 h-3.5" /> Target Date
          </label>
          <input 
            type="date" 
            className="form-input !py-3" 
            value={date} 
            onChange={e => setDate(e.target.value)} 
          />
        </div>
        <button 
          className="btn-primary w-full sm:w-auto !py-3 px-8" 
          onClick={fetchReport} 
          disabled={loading}
        >
          {loading ? 'Generating...' : (
            <>
              <BarChart3 className="w-4 h-4" /> Generate Report
            </>
          )}
        </button>
      </div>

      {/* Results */}
      {searched ? (
        <div className="animate-in slide-in-from-bottom-4 duration-500 fade-in">
          {/* Summary Card */}
          <div className="bg-gradient-to-br from-pharmacy-600/20 to-purple-600/10 border border-pharmacy-500/30 rounded-2xl p-8 mb-8 flex flex-col md:flex-row items-center gap-6 shadow-[0_0_40px_rgba(56,189,248,0.1)]">
            <div className="w-16 h-16 rounded-full bg-pharmacy-500/20 flex items-center justify-center flex-shrink-0">
              <TrendingUp className="w-8 h-8 text-pharmacy-400" />
            </div>
            <div className="text-center md:text-left flex-1">
              <p className="text-pharmacy-400 font-bold tracking-widest text-xs uppercase mb-1">
                Total Revenue Generated On
              </p>
              <h2 className="text-xl text-slate-300">
                {new Date(date).toLocaleDateString('en-GB', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </h2>
            </div>
            <div className="bg-dark-900/50 px-8 py-4 rounded-xl border border-dark-600 shadow-inner">
              <span className="text-3xl md:text-4xl font-black text-white">
                {Number(totalRevenue).toLocaleString()} <span className="text-lg text-slate-400">RWF</span>
              </span>
            </div>
          </div>

          {/* Breakdown Table */}
          <div className="card p-0 overflow-hidden border-dark-600">
            <div className="px-6 py-5 border-b border-dark-600 bg-dark-800/80">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Receipt className="w-5 h-5 text-pharmacy-400" /> Transaction Breakdown
              </h3>
            </div>
            <div className="table-container">
              <table className="table-main">
                <thead>
                  <tr>
                    <th className="table-th bg-dark-900 w-24">Sale ID</th>
                    <th className="table-th bg-dark-900">Customer</th>
                    <th className="table-th bg-dark-900">Medicine</th>
                    <th className="table-th bg-dark-900 text-center">Qty</th>
                    <th className="table-th bg-dark-900 text-right">Unit Price</th>
                    <th className="table-th bg-dark-900 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {report.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="py-12 text-center text-slate-500">
                        No transactions recorded for this specific date.
                      </td>
                    </tr>
                  ) : report.map((r, i) => (
                    <tr key={i} className="table-tr border-b border-dark-700 last:border-0">
                      <td className="px-4 py-3 font-mono">
                        <span className="px-2 py-1 rounded bg-dark-700 text-slate-400 text-xs">#{r.sale_id}</span>
                      </td>
                      <td className="px-4 py-3 text-sm font-semibold text-slate-200">{r.customer_name || <span className="text-slate-500 font-normal italic">Walk-in</span>}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{r.med_name}</td>
                      <td className="px-4 py-3 text-sm text-center text-slate-400">{r.quantity}</td>
                      <td className="px-4 py-3 text-sm text-right text-slate-400">{parseFloat(r.price).toLocaleString()} RWF</td>
                      <td className="px-4 py-3 text-sm text-right text-pharmacy-400 font-bold">{parseFloat(r.item_total).toLocaleString()} RWF</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="card py-16 flex flex-col items-center justify-center border-dashed border-dark-600 bg-dark-800/20">
          <div className="w-20 h-20 bg-dark-700/50 rounded-full flex items-center justify-center mb-4">
            <FileText className="w-10 h-10 text-dark-500" />
          </div>
          <h3 className="text-lg font-bold text-slate-300 mb-2">No Report Selected</h3>
          <p className="text-slate-500 text-sm max-w-sm text-center">
            Select a target date above and click <span className="text-pharmacy-400 font-semibold">Generate Report</span> to view detailed analytics and revenue summaries.
          </p>
        </div>
      )}
    </div>
  );
}

export default Reports;
