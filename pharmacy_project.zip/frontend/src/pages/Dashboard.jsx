import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Pill, Users, ShoppingCart, AlertCircle, CheckCircle2, TrendingUp, UserPlus, PackageSearch } from 'lucide-react';

function Dashboard() {
  const [stats, setStats] = useState({ totalMedicines: 0, totalCustomers: 0, totalSales: 0, lowStock: 0 });
  const [expiringMeds, setExpiringMeds] = useState([]);
  const username = localStorage.getItem('username') || 'User';
  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => { fetchDashboardData(); }, []); // eslint-disable-line

  const fetchDashboardData = async () => {
    try {
      const [medsRes, custsRes, salesRes, expiryRes] = await Promise.all([
        axios.get('http://localhost:5000/api/medicines', { headers }),
        axios.get('http://localhost:5000/api/customers', { headers }),
        axios.get('http://localhost:5000/api/sales', { headers }),
        axios.get('http://localhost:5000/api/medicines/alerts/expiring', { headers })
      ]);
      setStats({
        totalMedicines: medsRes.data.length,
        totalCustomers: custsRes.data.length,
        totalSales: salesRes.data.length,
        lowStock: medsRes.data.filter(m => m.quantity < 10).length
      });
      setExpiringMeds(expiryRes.data);
    } catch (error) {
      console.error('Dashboard load error:', error);
    }
  };

  const formatDate = d => new Date(d).toLocaleDateString();

  const statCards = [
    { icon: Pill, value: stats.totalMedicines, label: 'Total Medicines', trend: 'Active', color: 'text-pharmacy-400', bg: 'bg-pharmacy-500/10', border: 'border-pharmacy-500/20' },
    { icon: Users, value: stats.totalCustomers, label: 'Total Customers', trend: 'Registered', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
    { icon: ShoppingCart, value: stats.totalSales, label: 'Total Sales', trend: 'Recorded', color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
    { icon: AlertCircle, value: stats.lowStock, label: 'Low Stock Items', trend: 'Alert', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  ];

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
            Dashboard
          </h1>
          <p className="text-slate-400 mt-1">Good day, <span className="text-pharmacy-400 font-medium">{username}</span> — here's your pharmacy overview</p>
        </div>
      </div>

      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-br from-pharmacy-900/40 to-dark-800 border border-pharmacy-500/20 rounded-2xl p-6 md:p-8 mb-8 flex items-center gap-6">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-48 h-48 bg-pharmacy-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="w-16 h-16 rounded-2xl bg-pharmacy-500/20 flex items-center justify-center flex-shrink-0 border border-pharmacy-500/30 z-10 hidden sm:flex">
          <Pill className="w-8 h-8 text-pharmacy-400" />
        </div>
        <div className="z-10">
          <h2 className="text-xl font-bold text-white mb-2">PharmaCare Management System</h2>
          <p className="text-slate-300 text-sm max-w-2xl leading-relaxed">
            Manage your medicine inventory, customer records, sales, and generate reports — all in one streamlined interface. Use the sidebar to navigate through the modules.
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
        {statCards.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-dark-800/40 backdrop-blur-md border border-dark-600/50 rounded-2xl p-5 relative overflow-hidden group hover:border-dark-500 transition-colors">
              <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full blur-2xl opacity-20 group-hover:opacity-40 transition-opacity bg-current" style={{ color: 'var(--tw-gradient-from, currentColor)' }}></div>
              <div className="flex justify-between items-start mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${s.bg} border ${s.border}`}>
                  <Icon className={`w-6 h-6 ${s.color}`} />
                </div>
                <span className="px-2.5 py-1 rounded-full bg-dark-700/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border border-dark-600">
                  {s.trend}
                </span>
              </div>
              <div>
                <div className="text-3xl font-black text-white tracking-tight">{s.value}</div>
                <div className="text-sm font-medium text-slate-400 mt-1">{s.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Expiry Alerts */}
      {expiringMeds.length > 0 ? (
        <div className="bg-red-950/20 border border-red-500/20 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <AlertCircle className="w-6 h-6 text-red-500" />
            <h2 className="text-lg font-bold text-red-400">Expiry Alerts</h2>
            <span className="bg-red-500/10 text-red-500 text-xs font-bold px-2.5 py-1 rounded-full border border-red-500/20">
              {expiringMeds.length} Items
            </span>
          </div>
          
          <div className="table-container">
            <table className="table-main">
              <thead>
                <tr>
                  <th className="table-th !bg-red-950/40 !border-red-500/20 !text-red-400/80">Medicine Name</th>
                  <th className="table-th !bg-red-950/40 !border-red-500/20 !text-red-400/80">Quantity</th>
                  <th className="table-th !bg-red-950/40 !border-red-500/20 !text-red-400/80">Expiry Date</th>
                  <th className="table-th !bg-red-950/40 !border-red-500/20 !text-red-400/80">Status</th>
                </tr>
              </thead>
              <tbody>
                {expiringMeds.map(med => {
                  const daysLeft = Math.ceil((new Date(med.expiry_date) - new Date()) / (1000 * 60 * 60 * 24));
                  return (
                    <tr key={med.med_id} className="hover:bg-red-500/[0.02] border-b border-red-500/10 last:border-0">
                      <td className="px-4 py-3 text-sm font-semibold text-slate-200">{med.med_name}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{med.quantity}</td>
                      <td className="px-4 py-3 text-sm text-slate-300">{formatDate(med.expiry_date)}</td>
                      <td className="px-4 py-3 text-sm">
                        {daysLeft <= 0
                          ? <span className="badge-expired !bg-red-500/20">Expired</span>
                          : daysLeft <= 7
                          ? <span className="badge-expired">⚡ {daysLeft} days left</span>
                          : <span className="badge-warning !text-amber-500 !border-amber-500/30 !bg-amber-500/10">{daysLeft} days left</span>
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="card flex items-center gap-4 bg-emerald-950/10 border-emerald-500/10">
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
            <CheckCircle2 className="w-6 h-6 text-emerald-500" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-200">All inventory in good standing</h2>
            <p className="text-sm text-slate-400 mt-0.5">No medicines are expiring within the next 30 days.</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
