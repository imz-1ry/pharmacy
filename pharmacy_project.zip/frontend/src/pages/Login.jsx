import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Pill, User, Lock, ArrowRight, Activity, ShieldCheck, PieChart } from 'lucide-react';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('username', res.data.username);
      toast.success('Successfully logged in!');
      setTimeout(() => navigate('/'), 1500);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid credentials');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-dark-900 font-sans text-slate-200">
      <ToastContainer theme="dark" toastClassName="bg-dark-800 border border-dark-600 shadow-2xl rounded-xl" />
      
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-[45%] bg-gradient-to-br from-pharmacy-900 to-dark-900 border-r border-pharmacy-500/10 p-12 flex-col relative overflow-hidden">
        {/* Abstract Background Shapes */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-pharmacy-500/20 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[10%] -right-[10%] w-[60%] h-[60%] bg-indigo-500/10 rounded-full blur-[120px]"></div>
        </div>

        <div className="relative z-10 flex items-center gap-3 mb-16">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pharmacy-600 to-pharmacy-400 flex items-center justify-center shadow-lg shadow-pharmacy-500/30">
            <Pill className="w-7 h-7 text-white" />
          </div>
          <span className="text-2xl font-black tracking-tight text-white">PharmaCare</span>
        </div>

        <div className="relative z-10 flex-1 flex flex-col justify-center max-w-md">
          <h1 className="text-4xl font-extrabold text-white leading-tight mb-6">
            Smart Management for Modern Pharmacies.
          </h1>
          <p className="text-slate-400 text-lg mb-12">
            Streamline your inventory, track sales securely, and receive automated expiry alerts in one unified platform.
          </p>

          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-pharmacy-500/10 flex items-center justify-center border border-pharmacy-500/20 flex-shrink-0">
                <Activity className="w-5 h-5 text-pharmacy-400" />
              </div>
              <div>
                <h3 className="font-bold text-slate-200">Real-time Tracking</h3>
                <p className="text-sm text-slate-500 mt-1">Monitor stock levels and daily transactions instantly.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20 flex-shrink-0">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-bold text-slate-200">Secure Records</h3>
                <p className="text-sm text-slate-500 mt-1">Keep your customer data and sales history safe.</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center border border-purple-500/20 flex-shrink-0">
                <PieChart className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="font-bold text-slate-200">Advanced Analytics</h3>
                <p className="text-sm text-slate-500 mt-1">Generate comprehensive reports for better decisions.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-24 xl:px-32 relative">
        <div className="w-full max-w-sm mx-auto">
          {/* Mobile Header */}
          <div className="lg:hidden flex items-center justify-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pharmacy-600 to-pharmacy-400 flex items-center justify-center shadow-lg shadow-pharmacy-500/30">
              <Pill className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-black tracking-tight text-white">PharmaCare</span>
          </div>

          <div className="mb-10 text-center lg:text-left">
            <h2 className="text-3xl font-extrabold text-white mb-2">Welcome Back</h2>
            <p className="text-slate-400">Please sign in to access your dashboard.</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="form-label">Username</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <User className="w-5 h-5 text-slate-500" />
                </div>
                <input 
                  type="text" 
                  className="form-input pl-11" 
                  placeholder="Enter your username"
                  value={username} 
                  onChange={e => setUsername(e.target.value)} 
                  required 
                  disabled={loading}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="form-label !mb-0">Password</label>
                <a href="#" className="text-xs font-semibold text-pharmacy-400 hover:text-pharmacy-300 transition-colors">Forgot password?</a>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="w-5 h-5 text-slate-500" />
                </div>
                <input 
                  type="password" 
                  className="form-input pl-11" 
                  placeholder="••••••••"
                  value={password} 
                  onChange={e => setPassword(e.target.value)} 
                  required 
                  disabled={loading}
                />
              </div>
            </div>

            <button type="submit" className="btn-primary w-full py-3 mt-4 text-base" disabled={loading}>
              {loading ? (
                'Signing in...'
              ) : (
                <>
                  Sign In <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-slate-400">
            Don't have an account?{' '}
            <Link to="/register" className="font-bold text-pharmacy-400 hover:text-pharmacy-300 transition-colors">
              Create an account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
