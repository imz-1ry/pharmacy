import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Users, Search, Plus, Edit2, Trash2, X, Save, Phone } from 'lucide-react';
import ConfirmModal from '../components/ConfirmModal';

function Customers() {
  const [customers, setCustomers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingCust, setEditingCust] = useState(null);
  const [form, setForm] = useState({ name: '', phone: '' });
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmData, setConfirmData] = useState(null);

  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => { fetchCustomers(); }, []);

  const fetchCustomers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/customers', { headers });
      setCustomers(res.data);
    } catch {
      toast.error('Failed to load customers.');
    }
  };

  const openAdd = () => {
    setEditingCust(null);
    setForm({ name: '', phone: '' });
    setShowModal(true);
  };

  const openEdit = (c) => {
    setEditingCust(c);
    setForm({ name: c.name, phone: c.phone || '' });
    setShowModal(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      if (editingCust) {
        await axios.put(`http://localhost:5000/api/customers/${editingCust.cust_id}`, form, { headers });
        toast.success(`"${form.name}" updated!`);
      } else {
        await axios.post('http://localhost:5000/api/customers', form, { headers });
        toast.success(`"${form.name}" added!`);
      }
      setShowModal(false);
      fetchCustomers();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save customer.');
    } finally {
      setSaving(false);
    }
  };

  const askDelete = (c) => setConfirmData(c);

  const confirmDelete = async () => {
    const c = confirmData;
    setConfirmData(null);
    try {
      await axios.delete(`http://localhost:5000/api/customers/${c.cust_id}`, { headers });
      toast.success(`"${c.name}" deleted.`);
      fetchCustomers();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete customer.');
    }
  };

  const filtered = customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.phone && c.phone.includes(search))
  );

  const getInitial = (name) => name ? name.charAt(0).toUpperCase() : '?';

  return (
    <div className="page-container">
      {confirmData && (
        <ConfirmModal
          message={`Are you sure you want to delete customer "${confirmData.name}"?`}
          onConfirm={confirmDelete}
          onCancel={() => setConfirmData(null)}
        />
      )}

      <div className="page-header">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
            Customer Directory
          </h1>
          <p className="text-slate-400 mt-1">{customers.length} registered profiles</p>
        </div>
        <button className="btn-add" onClick={openAdd}>
          <Plus className="w-4 h-4" /> Add Customer
        </button>
      </div>

      <div className="card">
        {/* Search */}
        <div className="relative mb-6 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-500" />
          </div>
          <input
            type="text"
            className="form-input pl-10"
            placeholder="Search by name or phone..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <div className="table-container">
          <table className="table-main">
            <thead>
              <tr>
                <th className="table-th w-16">ID</th>
                <th className="table-th">Customer Name</th>
                <th className="table-th">Contact Number</th>
                <th className="table-th text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan="4" className="py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center">
                      <Users className="w-12 h-12 mb-3 text-dark-600" />
                      <p>{search ? 'No customers match your search.' : 'Directory is empty. Click "Add Customer" to get started.'}</p>
                    </div>
                  </td>
                </tr>
              ) : filtered.map(c => (
                <tr key={c.cust_id} className="table-tr">
                  <td className="table-td text-slate-500 font-mono text-xs">{c.cust_id}</td>
                  <td className="table-td font-semibold text-slate-200">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-pharmacy-600 to-pharmacy-400 flex items-center justify-center text-xs font-bold text-white flex-shrink-0 shadow-sm">
                        {getInitial(c.name)}
                      </div>
                      {c.name}
                    </div>
                  </td>
                  <td className="table-td">
                    <div className="flex items-center gap-2 text-slate-400">
                      <Phone className="w-4 h-4 text-slate-500" />
                      {c.phone || 'Not provided'}
                    </div>
                  </td>
                  <td className="table-td text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="btn-edit px-2.5 py-1.5" onClick={() => openEdit(c)} title="Edit">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="btn-delete px-2.5 py-1.5" onClick={() => askDelete(c)} title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[500] animate-in fade-in duration-200 p-4"
          onClick={() => !saving && setShowModal(false)}
        >
          <div 
            className="bg-dark-800 border border-dark-600 rounded-2xl p-6 md:p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-pharmacy-400" />
                {editingCust ? 'Edit Profile' : 'New Customer Profile'}
              </h2>
              <button 
                onClick={() => setShowModal(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
                disabled={saving}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSave}>
              <div className="form-group mb-4">
                <label className="form-label">Full Name</label>
                <input 
                  type="text" className="form-input" 
                  value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. John Doe" required 
                />
              </div>
              <div className="form-group mb-8">
                <label className="form-label">Phone Number</label>
                <input 
                  type="text" className="form-input" 
                  value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })}
                  placeholder="e.g. 0788 000 000" required 
                />
              </div>
              <div className="flex gap-3">
                <button type="button" className="flex-1 btn-cancel" onClick={() => setShowModal(false)} disabled={saving}>
                  Cancel
                </button>
                <button type="submit" className="flex-1 btn-primary" disabled={saving}>
                  {saving ? 'Saving...' : (
                    <>
                      <Save className="w-4 h-4" />
                      {editingCust ? 'Update' : 'Save'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Customers;
