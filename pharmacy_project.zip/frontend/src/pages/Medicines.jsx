import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { Pill, Search, Plus, Edit2, Trash2, X, Save } from 'lucide-react';
import ConfirmModal from '../components/ConfirmModal';

function Medicines() {
  const [medicines, setMedicines] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingMed, setEditingMed] = useState(null);
  const [form, setForm] = useState({ med_name: '', quantity: '', price: '', expiry_date: '' });
  const [search, setSearch] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmData, setConfirmData] = useState(null);

  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => { fetchMedicines(); }, []);

  const fetchMedicines = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/medicines', { headers });
      setMedicines(res.data);
    } catch {
      toast.error('Failed to load medicines.');
    }
  };

  const openAdd = () => {
    setEditingMed(null);
    setForm({ med_name: '', quantity: '', price: '', expiry_date: '' });
    setShowModal(true);
  };

  const openEdit = (med) => {
    setEditingMed(med);
    setForm({
      med_name: med.med_name,
      quantity: med.quantity,
      price: med.price,
      expiry_date: med.expiry_date ? med.expiry_date.split('T')[0] : ''
    });
    setShowModal(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      if (editingMed) {
        await axios.put(`http://localhost:5000/api/medicines/${editingMed.med_id}`, form, { headers });
        toast.success(`"${form.med_name}" updated!`);
      } else {
        await axios.post('http://localhost:5000/api/medicines', form, { headers });
        toast.success(`"${form.med_name}" added!`);
      }
      setShowModal(false);
      fetchMedicines();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save medicine.');
    } finally {
      setSaving(false);
    }
  };

  const askDelete = (med) => setConfirmData(med);

  const confirmDelete = async () => {
    const med = confirmData;
    setConfirmData(null);
    try {
      await axios.delete(`http://localhost:5000/api/medicines/${med.med_id}`, { headers });
      toast.success(`"${med.med_name}" deleted.`);
      fetchMedicines();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete medicine.');
    }
  };

  const getExpiryBadge = (expiryDate) => {
    const daysLeft = Math.ceil((new Date(expiryDate) - new Date()) / (1000 * 60 * 60 * 24));
    if (daysLeft < 0) return <span className="badge-expired">Expired</span>;
    if (daysLeft <= 30) return <span className="badge-warning">{daysLeft}d left</span>;
    return <span className="badge-ok">Good</span>;
  };

  const formatDate = (d) => new Date(d).toLocaleDateString();

  const filtered = medicines.filter(m =>
    m.med_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-container">
      {confirmData && (
        <ConfirmModal
          message={`Are you sure you want to delete "${confirmData.med_name}"?`}
          onConfirm={confirmDelete}
          onCancel={() => setConfirmData(null)}
        />
      )}

      <div className="page-header">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
            Medicines Inventory
          </h1>
          <p className="text-slate-400 mt-1">{medicines.length} total items tracked</p>
        </div>
        <button className="btn-add" onClick={openAdd}>
          <Plus className="w-4 h-4" /> Add Medicine
        </button>
      </div>

      <div className="card">
        {/* Search */}
        <div className="relative mb-6 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-500" />
          </div>
          <input
            type="text"
            className="form-input pl-10"
            placeholder="Search medicines by name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>

        <div className="table-container">
          <table className="table-main">
            <thead>
              <tr>
                <th className="table-th w-16">ID</th>
                <th className="table-th">Medicine Name</th>
                <th className="table-th">Stock</th>
                <th className="table-th">Price (RWF)</th>
                <th className="table-th">Expiry Date</th>
                <th className="table-th">Status</th>
                <th className="table-th text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center">
                      <Pill className="w-12 h-12 mb-3 text-dark-600" />
                      <p>{search ? 'No medicines match your search.' : 'Inventory is empty. Click "Add Medicine" to get started.'}</p>
                    </div>
                  </td>
                </tr>
              ) : filtered.map(med => (
                <tr key={med.med_id} className="table-tr">
                  <td className="table-td text-slate-500 font-mono text-xs">{med.med_id}</td>
                  <td className="table-td font-semibold text-slate-200">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded bg-pharmacy-500/10 flex items-center justify-center flex-shrink-0">
                        <Pill className="w-4 h-4 text-pharmacy-400" />
                      </div>
                      {med.med_name}
                    </div>
                  </td>
                  <td className="table-td">
                    <span className={`font-semibold ${med.quantity < 10 ? 'text-red-400' : 'text-slate-300'}`}>
                      {med.quantity}
                    </span>
                  </td>
                  <td className="table-td">{parseFloat(med.price).toLocaleString()}</td>
                  <td className="table-td text-slate-400">{formatDate(med.expiry_date)}</td>
                  <td className="table-td">{getExpiryBadge(med.expiry_date)}</td>
                  <td className="table-td text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="btn-edit px-2.5 py-1.5" onClick={() => openEdit(med)} title="Edit">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button className="btn-delete px-2.5 py-1.5" onClick={() => askDelete(med)} title="Delete">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[500] animate-in fade-in duration-200 p-4"
          onClick={() => !saving && setShowModal(false)}
        >
          <div 
            className="bg-dark-800 border border-dark-600 rounded-2xl p-6 md:p-8 w-full max-w-md shadow-2xl animate-in zoom-in-95 duration-200"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Pill className="w-5 h-5 text-pharmacy-400" />
                {editingMed ? 'Edit Medicine' : 'Add New Medicine'}
              </h2>
              <button 
                onClick={() => setShowModal(false)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
                disabled={saving}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSave}>
              <div className="form-group">
                <label className="form-label">Medicine Name</label>
                <input
                  type="text" className="form-input"
                  value={form.med_name}
                  onChange={e => setForm({ ...form, med_name: e.target.value })}
                  placeholder="e.g. Paracetamol 500mg" required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="form-label">Stock Qty</label>
                  <input 
                    type="number" className="form-input"
                    value={form.quantity}
                    onChange={e => setForm({ ...form, quantity: e.target.value })}
                    placeholder="0" required min="0" 
                  />
                </div>
                <div>
                  <label className="form-label">Price (RWF)</label>
                  <input 
                    type="number" className="form-input"
                    value={form.price}
                    onChange={e => setForm({ ...form, price: e.target.value })}
                    placeholder="0" required min="0" 
                  />
                </div>
              </div>
              
              <div className="form-group mb-8">
                <label className="form-label">Expiry Date</label>
                <input 
                  type="date" className="form-input"
                  value={form.expiry_date}
                  onChange={e => setForm({ ...form, expiry_date: e.target.value })}
                  required 
                />
              </div>
              
              <div className="flex gap-3">
                <button type="button" className="flex-1 btn-cancel" onClick={() => setShowModal(false)} disabled={saving}>
                  Cancel
                </button>
                <button type="submit" className="flex-1 btn-primary" disabled={saving}>
                  {saving ? 'Saving...' : (
                    <>
                      <Save className="w-4 h-4" />
                      {editingMed ? 'Update' : 'Save'}
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Medicines;
