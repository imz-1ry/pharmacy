import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { ShoppingCart, Plus, Eye, Trash2, X, Save, Receipt, User, Calendar, Pill } from 'lucide-react';
import ConfirmModal from '../components/ConfirmModal';

function Sales() {
  const [sales, setSales] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [showDetails, setShowDetails] = useState(null);
  const [saleDetails, setSaleDetails] = useState([]);
  const [saving, setSaving] = useState(false);
  const [confirmData, setConfirmData] = useState(null);
  const [form, setForm] = useState({
    cust_id: '',
    date: new Date().toISOString().split('T')[0],
    items: [{ med_id: '', quantity: '' }]
  });

  const token = localStorage.getItem('token');
  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      const [s, c, m] = await Promise.all([
        axios.get('http://localhost:5000/api/sales', { headers }),
        axios.get('http://localhost:5000/api/customers', { headers }),
        axios.get('http://localhost:5000/api/medicines', { headers })
      ]);
      setSales(s.data);
      setCustomers(c.data);
      setMedicines(m.data);
    } catch {
      toast.error('Failed to load sales data.');
    }
  };

  const openNewSale = () => {
    setForm({
      cust_id: '',
      date: new Date().toISOString().split('T')[0],
      items: [{ med_id: '', quantity: '' }]
    });
    setShowModal(true);
  };

  const handleAddItem = () => {
    setForm(prev => ({ ...prev, items: [...prev.items, { med_id: '', quantity: '' }] }));
  };

  const handleRemoveItem = (index) => {
    setForm(prev => {
      const items = prev.items.filter((_, i) => i !== index);
      return { ...prev, items: items.length ? items : [{ med_id: '', quantity: '' }] };
    });
  };

  const handleItemChange = (index, field, value) => {
    setForm(prev => {
      const items = [...prev.items];
      items[index] = { ...items[index], [field]: value };
      return { ...prev, items };
    });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (saving) return;

    for (const item of form.items) {
      if (!item.med_id || !item.quantity) {
        toast.warning('Please fill in all sale items.');
        return;
      }
    }

    setSaving(true);
    try {
      await axios.post('http://localhost:5000/api/sales', form, { headers });
      toast.success('Sale recorded successfully!');
      setShowModal(false);
      fetchData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to record sale.');
    } finally {
      setSaving(false);
    }
  };

  const handleViewDetails = async (saleId) => {
    try {
      const res = await axios.get(`http://localhost:5000/api/sales/${saleId}/details`, { headers });
      setSaleDetails(res.data);
      setShowDetails(saleId);
    } catch {
      toast.error('Failed to load sale details.');
    }
  };

  const askDelete = (sale) => setConfirmData(sale);

  const confirmDelete = async () => {
    const sale = confirmData;
    setConfirmData(null);
    try {
      await axios.delete(`http://localhost:5000/api/sales/${sale.sale_id}`, { headers });
      toast.success(`Sale #${sale.sale_id} deleted.`);
      fetchData();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete sale.');
    }
  };

  const formatDate = (d) => new Date(d).toLocaleDateString();
  const grandTotal = saleDetails.reduce((sum, d) => sum + parseFloat(d.total || 0), 0);

  return (
    <div className="page-container">
      {confirmData && (
        <ConfirmModal
          message={`Are you sure you want to delete Sale #${confirmData.sale_id}? This cannot be undone.`}
          onConfirm={confirmDelete}
          onCancel={() => setConfirmData(null)}
        />
      )}

      <div className="page-header">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">
            Sales & Transactions
          </h1>
          <p className="text-slate-400 mt-1">{sales.length} total records</p>
        </div>
        <button className="btn-add" onClick={openNewSale}>
          <Plus className="w-4 h-4" /> New Sale
        </button>
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="table-container">
          <table className="table-main">
            <thead>
              <tr>
                <th className="table-th w-24">Sale ID</th>
                <th className="table-th">Customer</th>
                <th className="table-th">Date</th>
                <th className="table-th text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sales.length === 0 ? (
                <tr>
                  <td colSpan="4" className="py-12 text-center text-slate-500">
                    <div className="flex flex-col items-center">
                      <ShoppingCart className="w-12 h-12 mb-3 text-dark-600" />
                      <p>No sales recorded yet. Click "New Sale" to start.</p>
                    </div>
                  </td>
                </tr>
              ) : sales.map(s => (
                <tr key={s.sale_id} className="table-tr">
                  <td className="table-td font-mono">
                    <span className="px-2.5 py-1 rounded-md bg-pharmacy-500/10 text-pharmacy-400 text-xs font-bold border border-pharmacy-500/20">
                      #{s.sale_id}
                    </span>
                  </td>
                  <td className="table-td font-semibold text-slate-200">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-500" />
                      {s.customer_name || <span className="text-slate-500 font-normal italic">Walk-in Customer</span>}
                    </div>
                  </td>
                  <td className="table-td text-slate-400">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-slate-500" />
                      {formatDate(s.date)}
                    </div>
                  </td>
                  <td className="table-td text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="btn-view px-2.5 py-1.5" onClick={() => handleViewDetails(s.sale_id)} title="View Receipt">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="btn-delete px-2.5 py-1.5" onClick={() => askDelete(s)} title="Delete Sale">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Sale Details Modal */}
      {showDetails && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[500] animate-in fade-in duration-200 p-4" onClick={() => setShowDetails(null)}>
          <div className="bg-dark-800 border border-dark-600 rounded-2xl p-6 md:p-8 w-full max-w-2xl shadow-2xl animate-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6 border-b border-dark-600 pb-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <Receipt className="w-5 h-5 text-pharmacy-400" />
                Receipt #{showDetails}
              </h2>
              <button onClick={() => setShowDetails(null)} className="p-1 text-slate-400 hover:text-white transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="table-container mb-6 border border-dark-600 rounded-xl overflow-hidden">
              <table className="table-main">
                <thead>
                  <tr>
                    <th className="table-th bg-dark-900">Medicine Item</th>
                    <th className="table-th bg-dark-900 text-center">Qty</th>
                    <th className="table-th bg-dark-900 text-right">Unit Price</th>
                    <th className="table-th bg-dark-900 text-right">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {saleDetails.length === 0 ? (
                    <tr><td colSpan="4" className="text-center text-slate-500 py-8">No items found.</td></tr>
                  ) : saleDetails.map((d, i) => (
                    <tr key={i} className="border-b border-dark-700 last:border-0">
                      <td className="px-4 py-3 text-sm font-semibold text-slate-200">{d.med_name}</td>
                      <td className="px-4 py-3 text-sm text-center text-slate-400">{d.quantity}</td>
                      <td className="px-4 py-3 text-sm text-right text-slate-400">{parseFloat(d.price).toLocaleString()} RWF</td>
                      <td className="px-4 py-3 text-sm text-right text-pharmacy-400 font-bold">{parseFloat(d.total).toLocaleString()} RWF</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {saleDetails.length > 0 && (
              <div className="flex justify-end mb-8">
                <div className="bg-gradient-to-r from-pharmacy-900/20 to-dark-700 border border-dark-500 rounded-xl px-6 py-4 flex items-center gap-8 shadow-inner">
                  <span className="text-slate-400 font-bold uppercase tracking-widest text-xs">Grand Total</span>
                  <span className="text-2xl font-black text-white">{grandTotal.toLocaleString()} RWF</span>
                </div>
              </div>
            )}
            
            <div className="flex justify-end">
              <button className="btn-cancel" onClick={() => setShowDetails(null)}>Close Receipt</button>
            </div>
          </div>
        </div>
      )}

      {/* New Sale Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[500] animate-in fade-in duration-200 p-4" onClick={() => !saving && setShowModal(false)}>
          <div className="bg-dark-800 border border-dark-600 rounded-2xl p-6 md:p-8 w-full max-w-2xl shadow-2xl animate-in zoom-in-95 duration-200" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-pharmacy-400" />
                Record New Sale
              </h2>
              <button onClick={() => setShowModal(false)} className="p-1 text-slate-400 hover:text-white transition-colors" disabled={saving}>
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleSave}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6 p-5 bg-dark-900/50 border border-dark-600/50 rounded-xl">
                <div>
                  <label className="form-label">Customer</label>
                  <select className="form-input" value={form.cust_id} onChange={e => setForm(prev => ({ ...prev, cust_id: e.target.value }))} required>
                    <option value="">Select customer</option>
                    {customers.map(c => <option key={c.cust_id} value={c.cust_id}>{c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="form-label">Date</label>
                  <input type="date" className="form-input" value={form.date} onChange={e => setForm(prev => ({ ...prev, date: e.target.value }))} required />
                </div>
              </div>

              <div className="mb-4 flex items-center justify-between">
                <label className="text-xs font-bold text-pharmacy-400 uppercase tracking-wider flex items-center gap-2">
                  <Pill className="w-4 h-4" /> Sale Items ({form.items.length})
                </label>
                <button type="button" onClick={handleAddItem} className="text-xs font-bold text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 border border-emerald-500/20">
                  <Plus className="w-3 h-3" /> Add Row
                </button>
              </div>

              <div className="space-y-3 mb-8 max-h-[40vh] overflow-y-auto custom-scrollbar pr-2">
                {form.items.map((item, i) => (
                  <div className="flex items-start gap-3 p-3 bg-dark-700/30 border border-dark-600 rounded-xl" key={i}>
                    <div className="flex-1">
                      <select className="form-input" value={item.med_id} onChange={e => handleItemChange(i, 'med_id', e.target.value)} required>
                        <option value="">Select medicine</option>
                        {medicines.map(m => <option key={m.med_id} value={m.med_id}>{m.med_name} (Stock: {m.quantity})</option>)}
                      </select>
                    </div>
                    <div className="w-24">
                      <input type="number" className="form-input text-center" placeholder="Qty" value={item.quantity} onChange={e => handleItemChange(i, 'quantity', e.target.value)} required min="1" />
                    </div>
                    <button type="button" className="p-2.5 bg-red-500/10 text-red-500 hover:bg-red-500/20 border border-red-500/20 rounded-xl transition-colors mt-0.5" onClick={() => handleRemoveItem(i)} title="Remove row">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 pt-4 border-t border-dark-600">
                <button type="button" className="flex-1 btn-cancel" onClick={() => setShowModal(false)} disabled={saving}>
                  Cancel
                </button>
                <button type="submit" className="flex-[2] btn-primary" disabled={saving}>
                  {saving ? 'Processing...' : (
                    <>
                      <Save className="w-4 h-4" />
                      Complete Transaction
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Sales;
