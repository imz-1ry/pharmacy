// Main App Component - Sidebar layout with Toast notifications
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Medicines from './pages/Medicines';
import Customers from './pages/Customers';
import Sales from './pages/Sales';
import Reports from './pages/Reports';
import PrivateRoute from './components/PrivateRoute';

// Layout wrapper: Sidebar + main content area
function AppLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-dark-900 font-sans text-slate-200">
      <Sidebar />
      <main className="flex-1 ml-[72px] md:ml-[260px] transition-all duration-300 min-h-screen overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}

function App() {
  return (
    <Router>
      {/* Global toast container */}
      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="dark"
        toastClassName="bg-dark-800 border border-dark-600 shadow-2xl rounded-xl"
      />

      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Protected Routes with Sidebar Layout */}
        <Route path="/" element={
          <PrivateRoute>
            <AppLayout><Dashboard /></AppLayout>
          </PrivateRoute>
        } />
        <Route path="/medicines" element={
          <PrivateRoute>
            <AppLayout><Medicines /></AppLayout>
          </PrivateRoute>
        } />
        <Route path="/customers" element={
          <PrivateRoute>
            <AppLayout><Customers /></AppLayout>
          </PrivateRoute>
        } />
        <Route path="/sales" element={
          <PrivateRoute>
            <AppLayout><Sales /></AppLayout>
          </PrivateRoute>
        } />
        <Route path="/reports" element={
          <PrivateRoute>
            <AppLayout><Reports /></AppLayout>
          </PrivateRoute>
        } />

        {/* Redirect unknown routes to login */}
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </Router>
  );
}

export default App;
