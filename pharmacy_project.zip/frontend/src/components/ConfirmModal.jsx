import React from 'react';
import { AlertTriangle } from 'lucide-react';

function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[500] animate-in fade-in duration-200"
      onClick={onCancel}
    >
      <div 
        className="bg-dark-800 border border-dark-600 rounded-2xl p-6 w-[90%] max-w-sm shadow-2xl animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex flex-col items-center text-center">
          <div className="w-14 h-14 rounded-full bg-red-500/10 flex items-center justify-center mb-4">
            <AlertTriangle className="w-7 h-7 text-red-500" />
          </div>
          <h2 className="text-lg font-bold text-slate-200 mb-2">Confirm Action</h2>
          <p className="text-sm text-slate-400 mb-6 leading-relaxed">
            {message}
          </p>
          <div className="flex w-full gap-3">
            <button 
              className="flex-1 btn bg-dark-700 hover:bg-dark-600 text-slate-300 shadow-none border border-dark-500" 
              onClick={onCancel}
            >
              Cancel
            </button>
            <button 
              className="flex-1 btn bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 font-bold" 
              onClick={onConfirm}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ConfirmModal;
