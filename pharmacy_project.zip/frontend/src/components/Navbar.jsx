// Navbar Component - Top navigation bar
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

function Navbar() {
  const location = useLocation(); // Get current page path
  const navigate = useNavigate();
  const username = localStorage.getItem('username');

  // Logout function - clear token and redirect
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    navigate('/login');
  };

  return (
    <nav className="navbar">
      {/* Brand Logo */}
      <Link to="/" className="navbar-brand">
        💊 <span>PharmaCare</span>
      </Link>

      {/* Navigation Links */}
      <ul className="navbar-links">
        <li>
          <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
            Dashboard
          </Link>
        </li>
        <li>
          <Link to="/medicines" className={location.pathname === '/medicines' ? 'active' : ''}>
            Medicines
          </Link>
        </li>
        <li>
          <Link to="/customers" className={location.pathname === '/customers' ? 'active' : ''}>
            Customers
          </Link>
        </li>
        <li>
          <Link to="/sales" className={location.pathname === '/sales' ? 'active' : ''}>
            Sales
          </Link>
        </li>
        <li>
          <Link to="/reports" className={location.pathname === '/reports' ? 'active' : ''}>
            Reports
          </Link>
        </li>
      </ul>

      {/* User Info & Logout */}
      <div className="navbar-user">
        <span>👤 {username}</span>
        <button className="btn-logout" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </nav>
  );
}

export default Navbar;
