import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { LayoutDashboard, Pill, Users, ShoppingCart, FileText, LogOut, Menu } from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/medicines', label: 'Medicines', icon: Pill },
  { path: '/customers', label: 'Customers', icon: Users },
  { path: '/sales', label: 'Sales', icon: ShoppingCart },
  { path: '/reports', label: 'Reports', icon: FileText },
];

function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const username = localStorage.getItem('username') || 'User';
  const [collapsed, setCollapsed] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    toast.info('Logged out successfully');
    navigate('/login');
  };

  return (
    <aside className={`fixed top-0 left-0 h-screen bg-gradient-to-b from-dark-900 to-dark-800 border-r border-pharmacy-500/10 flex flex-col z-[200] transition-all duration-300 ${collapsed ? 'w-[72px]' : 'w-[72px] md:w-[260px]'}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-pharmacy-500/10 min-h-[70px]">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pharmacy-600 to-pharmacy-400 flex items-center justify-center shadow-lg shadow-pharmacy-500/20 flex-shrink-0">
            <Pill className="w-6 h-6 text-white" />
          </div>
          <span className={`text-lg font-extrabold bg-clip-text text-transparent bg-gradient-to-br from-white to-slate-400 whitespace-nowrap transition-opacity duration-300 ${collapsed ? 'opacity-0 hidden md:block md:opacity-0' : 'opacity-100 hidden md:block'}`}>
            PharmaCare
          </span>
        </div>
        <button 
          className="hidden md:flex p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          onClick={() => setCollapsed(!collapsed)}
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* User Info */}
      <div className={`flex items-center gap-3 p-4 border-b border-pharmacy-500/10 overflow-hidden transition-all duration-300 ${collapsed ? 'hidden md:flex md:justify-center' : 'hidden md:flex'}`}>
        <div className="w-10 h-10 rounded-full bg-dark-700 border border-dark-600 flex items-center justify-center font-bold text-white flex-shrink-0">
          {username.charAt(0).toUpperCase()}
        </div>
        <div className={`flex-col ${collapsed ? 'hidden' : 'flex'}`}>
          <span className="text-sm font-bold text-slate-200 truncate w-32">{username}</span>
          <span className="text-xs text-pharmacy-500 font-medium">Pharmacist</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 overflow-y-auto overflow-x-hidden custom-scrollbar">
        <div className={`px-5 pb-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider ${collapsed ? 'hidden' : 'hidden md:block'}`}>
          Main Menu
        </div>
        <ul className="px-3 space-y-1">
          {navItems.map(item => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 group relative ${
                    isActive 
                      ? 'bg-pharmacy-500/10 text-pharmacy-400 font-semibold' 
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                  }`}
                  title={collapsed ? item.label : ''}
                >
                  <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-pharmacy-400' : 'text-slate-500 group-hover:text-slate-300'}`} />
                  <span className={`whitespace-nowrap ${collapsed ? 'hidden' : 'hidden md:block'}`}>
                    {item.label}
                  </span>
                  {isActive && !collapsed && (
                    <span className="absolute right-3 w-1.5 h-1.5 rounded-full bg-pharmacy-400 hidden md:block" />
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer / Logout */}
      <div className="p-3 border-t border-pharmacy-500/10">
        <button 
          onClick={handleLogout}
          className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-red-400/80 hover:bg-red-500/10 hover:text-red-400 transition-colors group`}
          title={collapsed ? 'Logout' : ''}
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          <span className={`whitespace-nowrap font-medium ${collapsed ? 'hidden' : 'hidden md:block'}`}>Logout</span>
        </button>
      </div>
    </aside>
  );
}

export default Sidebar;
