// PrivateRoute Component - Protects routes from unauthenticated users
import React from 'react';
import { Navigate } from 'react-router-dom';

function PrivateRoute({ children }) {
  // Check if user has a token (is logged in)
  const token = localStorage.getItem('token');

  // If no token, redirect to login page
  if (!token) {
    return <Navigate to="/login" />;
  }

  // If token exists, show the page
  return children;
}

export default PrivateRoute;
